# Timewallet 2.0 cloud setup

Timewallet uses your own private Firebase project for Google sign-in, the shared backup database, and receipt-image storage.

1. Open the [Firebase console](https://console.firebase.google.com/) and create a project.
2. Add a **Web app**, then copy its `firebaseConfig` object.
3. In **Authentication → Sign-in method**, enable **Google**.
4. Create a **Cloud Firestore** database.
5. Create **Storage** for receipt images.
6. Open Timewallet with `Start Timewallet.command`, go to **Settings → Google cloud backup**, paste the configuration, and choose **Connect Google**.

Use these Firestore rules so every user can access only their own backup:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Use these Storage rules so every user can access only their own receipts:

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

For a hosted web/mobile version, add its domain under **Authentication → Settings → Authorized domains**. Firebase configuration identifies the project but is not a password; the security rules above protect the data.
