(function(){
  const SDK_VERSION='10.14.1';
  const SDK_FILES=['firebase-app-compat.js','firebase-auth-compat.js','firebase-firestore-compat.js','firebase-storage-compat.js'];
  const CONFIG_KEY='tw-firebase-config',AUTO_KEY='tw-cloud-auto',LAST_KEY='tw-cloud-last-sync';
  const state={app:null,auth:null,db:null,storage:null,user:null,loading:null,busy:false,applying:false,timer:null,lastFingerprint:''};
  const el=id=>document.getElementById(id);

  function setStatus(message,tone='idle'){
    if(el('cloudStatus'))el('cloudStatus').textContent=message;
    if(el('cloudBadge')){el('cloudBadge').textContent=tone==='connected'?'Connected':tone==='busy'?'Syncing…':tone==='error'?'Needs attention':'Not connected';el('cloudBadge').classList.toggle('connected',tone==='connected')}
  }
  function setBusy(value,message){state.busy=value;['cloudConnect','cloudBackup','cloudRestore','cloudDisconnect'].forEach(id=>{if(el(id))el(id).disabled=value||(id!=='cloudConnect'&&!state.user)});if(message)setStatus(message,'busy')}
  function parseConfig(value){
    const text=String(value||'').trim();if(!text)throw new Error('Paste your Firebase web configuration first.');
    const body=text.includes('{')?text.slice(text.indexOf('{'),text.lastIndexOf('}')+1):text;
    try{return JSON.parse(body.replace(/([,{]\s*)([A-Za-z][A-Za-z0-9]*)(\s*:)/g,'$1"$2"$3').replace(/'/g,'"'))}catch{throw new Error('The Firebase configuration format is not valid.')}
  }
  function loadScript(file){return new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=`https://www.gstatic.com/firebasejs/${SDK_VERSION}/${file}`;script.onload=resolve;script.onerror=()=>reject(new Error('Cloud libraries could not load. Check your internet connection.'));document.head.appendChild(script)})}
  async function loadSdk(){if(window.firebase)return;if(!state.loading)state.loading=SDK_FILES.reduce((promise,file)=>promise.then(()=>loadScript(file)),Promise.resolve());return state.loading}
  function cleanSettings(){const copy={...settings};delete copy.rates;return copy}
  function cloudPayload(){return{version:2,settings:cleanSettings(),jobs:structuredClone(jobs),categories:structuredClone(categories),timeEntries:structuredClone(timeEntries),expenses:structuredClone(expenses),transfers:structuredClone(transfers)}}
  function fingerprint(payload=cloudPayload()){return JSON.stringify(payload)}
  function backupRef(){return state.db.collection('users').doc(state.user.uid).collection('backups').doc('timewallet')}
  function formatSync(value){if(!value)return'No cloud backup yet.';const date=value.toDate?value.toDate():new Date(value);return`Last cloud backup: ${date.toLocaleString()}`}
  function updateAccount(){
    const connected=!!state.user;el('cloudBackup').disabled=!connected||state.busy;el('cloudRestore').disabled=!connected||state.busy;el('cloudDisconnect').classList.toggle('hidden',!connected);el('cloudConnect').classList.toggle('hidden',connected);
    el('cloudUserName').textContent=connected?(state.user.displayName||state.user.email||'Google account'):'Google account';
    el('cloudLastSync').textContent=formatSync(localStorage.getItem(LAST_KEY));
    if(connected)setStatus(`Signed in as ${state.user.email||state.user.displayName}`,'connected');
  }
  async function initialize(config){
    await loadSdk();
    if(!window.firebase.apps.length)state.app=window.firebase.initializeApp(config);else state.app=window.firebase.app();
    state.auth=window.firebase.auth();state.db=window.firebase.firestore();state.storage=window.firebase.storage();
    await state.auth.setPersistence(window.firebase.auth.Auth.Persistence.LOCAL);
    state.auth.onAuthStateChanged(user=>{state.user=user;updateAccount();if(user)setTimeout(inspectCloud,250)});
  }
  async function ensureConfigured(){
    const config=parseConfig(el('firebaseConfig').value);localStorage.setItem(CONFIG_KEY,JSON.stringify(config));
    if(!state.auth)await initialize(config);return config
  }
  async function connect(){
    if(location.protocol==='file:')throw new Error('Open Timewallet using Start Timewallet.command before connecting Google.');
    if(!el('firebaseConfig').value.trim()){
      setStatus('Paste your Firebase web configuration first.','error');
      showToast('Paste your Firebase web configuration first.');
      return;
    }
    await ensureConfigured();const provider=new window.firebase.auth.GoogleAuthProvider();await state.auth.signInWithPopup(provider)
  }
  async function uploadReceipt(expense){
    if(!expense.receipt||!expense.receipt.startsWith('data:'))return expense;
    const type=expense.receipt.slice(5,expense.receipt.indexOf(';'))||'image/jpeg',extension=type.split('/')[1]?.replace('jpeg','jpg')||'jpg';
    const ref=state.storage.ref().child(`users/${state.user.uid}/receipts/${expense.id}.${extension}`);await ref.putString(expense.receipt,'data_url',{contentType:type});
    return{...expense,receipt:await ref.getDownloadURL()}
  }
  async function backupCloud(manual=false){
    if(!state.user||state.busy||state.applying)return;
    const before=cloudPayload(),beforeFingerprint=fingerprint(before);if(!manual&&beforeFingerprint===state.lastFingerprint)return;
    setBusy(true,'Saving your Timewallet cloud backup…');
    try{
      const uploaded=[];for(const expense of before.expenses)uploaded.push(await uploadReceipt(expense));
      const payload={...before,expenses:uploaded,updatedAt:window.firebase.firestore.FieldValue.serverTimestamp(),deviceUpdatedAt:new Date().toISOString()};
      await backupRef().set(payload);state.lastFingerprint=fingerprint({...before,expenses:uploaded});
      if(JSON.stringify(uploaded)!==JSON.stringify(expenses)){state.applying=true;expenses=uploaded;persist();state.applying=false}
      const now=new Date().toISOString();localStorage.setItem(LAST_KEY,now);el('cloudLastSync').textContent=formatSync(now);setStatus('Cloud backup is up to date.','connected');if(manual)showToast('Cloud backup completed')
    }catch(error){console.error('Cloud backup failed',error);setStatus(error.message||'Cloud backup failed.','error');if(manual)showToast('Cloud backup failed')}
    finally{setBusy(false);updateAccount()}
  }
  async function restoreCloud(manual=false){
    if(!state.user||state.busy)return false;setBusy(true,'Restoring your cloud backup…');
    try{
      const snapshot=await backupRef().get();if(!snapshot.exists){setStatus('No cloud backup exists yet.','connected');if(manual)showToast('No cloud backup found');return false}
      const data=snapshot.data();localStorage.setItem('tw-cloud-pre-restore',JSON.stringify(cloudPayload()));state.applying=true;
      settings={...DEFAULT_SETTINGS,...data.settings,rates:{...DEFAULT_SETTINGS.rates,...settings.rates}};jobs=Array.isArray(data.jobs)?data.jobs:jobs;categories=Array.isArray(data.categories)?data.categories:categories;timeEntries=Array.isArray(data.timeEntries)?data.timeEntries:timeEntries;expenses=Array.isArray(data.expenses)?data.expenses:expenses;transfers=Array.isArray(data.transfers)?data.transfers:transfers;
      renderAll();state.applying=false;state.lastFingerprint=fingerprint();const stamp=data.updatedAt||data.deviceUpdatedAt||new Date().toISOString();localStorage.setItem(LAST_KEY,data.deviceUpdatedAt||new Date().toISOString());el('cloudLastSync').textContent=formatSync(stamp);setStatus('Cloud data restored on this device.','connected');if(manual)showToast('Cloud backup restored');return true
    }catch(error){state.applying=false;console.error('Cloud restore failed',error);setStatus(error.message||'Cloud restore failed.','error');if(manual)showToast('Cloud restore failed');return false}
    finally{setBusy(false);updateAccount()}
  }
  async function inspectCloud(){
    if(state.busy)return;setBusy(true,'Checking your cloud backup…');let hasBackup=false;
    try{const snapshot=await backupRef().get();hasBackup=snapshot.exists}catch(error){console.error('Cloud check failed',error);setStatus(error.message||'Could not check cloud backup.','error');setBusy(false);updateAccount();return}
    setBusy(false);updateAccount();if(hasBackup)await restoreCloud(false);else{state.lastFingerprint='';await backupCloud(true)}
  }
  function scheduleBackup(){if(state.applying||!state.user||el('cloudAutoSync').checked===false)return;clearTimeout(state.timer);state.timer=setTimeout(()=>backupCloud(false),1800)}
  async function run(action){try{setBusy(true);await action()}catch(error){setStatus(error.message||'Cloud connection failed.','error');showToast(error.message||'Cloud connection failed')}finally{setBusy(false);updateAccount()}}
  el('firebaseConfig').value=localStorage.getItem(CONFIG_KEY)||'';el('cloudAutoSync').checked=localStorage.getItem(AUTO_KEY)!=='false';
  el('cloudConnect').addEventListener('click',()=>run(connect));el('cloudBackup').addEventListener('click',()=>backupCloud(true));el('cloudRestore').addEventListener('click',()=>restoreCloud(true));el('cloudDisconnect').addEventListener('click',()=>run(()=>state.auth.signOut()));el('cloudAutoSync').addEventListener('change',e=>{localStorage.setItem(AUTO_KEY,e.target.checked);if(e.target.checked)scheduleBackup()});
  window.addEventListener('timewallet:data-changed',scheduleBackup);
  const saved=localStorage.getItem(CONFIG_KEY);if(saved&&location.protocol!=='file:')run(()=>initialize(JSON.parse(saved)));else updateAccount();
})();
